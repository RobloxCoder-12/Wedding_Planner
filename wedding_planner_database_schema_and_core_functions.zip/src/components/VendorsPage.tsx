import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { 
  PlusIcon, 
  MagnifyingGlassIcon,
  BuildingStorefrontIcon,
  StarIcon,
  PhoneIcon,
  EnvelopeIcon,
  GlobeAltIcon,
  CurrencyDollarIcon,
  TagIcon,
  EyeIcon,
  PencilIcon,
  TrashIcon
} from "@heroicons/react/24/outline";
import { StarIcon as StarIconSolid } from "@heroicons/react/24/solid";

export function VendorsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [priceFilter, setPriceFilter] = useState("");
  const [showAddForm, setShowAddForm] = useState(false);

  // Mock vendors data since we don't have vendors functions yet
  const mockVendors = [
    {
      _id: "1",
      name: "Elegant Flowers Co.",
      category: "flowers",
      email: "info@elegantflowers.com",
      phone: "(555) 123-4567",
      website: "www.elegantflowers.com",
      rating: 4.8,
      priceRange: "$$$",
      description: "Premium floral arrangements for weddings and special events. Specializing in romantic, garden-style bouquets and centerpieces.",
      _creationTime: Date.now() - 86400000,
    },
    {
      _id: "2",
      name: "Grand Ballroom Hotel",
      category: "venue",
      email: "events@grandballroom.com",
      phone: "(555) 234-5678",
      website: "www.grandballroom.com",
      rating: 4.9,
      priceRange: "$$$$",
      description: "Luxury wedding venue with stunning ballrooms, outdoor gardens, and full-service catering. Accommodates 50-500 guests.",
      _creationTime: Date.now() - 172800000,
    },
    {
      _id: "3",
      name: "Melody Music Services",
      category: "music",
      email: "bookings@melodymusic.com",
      phone: "(555) 345-6789",
      website: "www.melodymusic.com",
      rating: 4.7,
      priceRange: "$$",
      description: "Professional DJ and live music services. From ceremony to reception, we provide the perfect soundtrack for your special day.",
      _creationTime: Date.now() - 259200000,
    },
    {
      _id: "4",
      name: "Capture Moments Photography",
      category: "photography",
      email: "hello@capturemoments.com",
      phone: "(555) 456-7890",
      website: "www.capturemoments.com",
      rating: 5.0,
      priceRange: "$$$",
      description: "Award-winning wedding photographers specializing in candid, emotional storytelling through beautiful imagery.",
      _creationTime: Date.now() - 345600000,
    },
    {
      _id: "5",
      name: "Gourmet Catering Plus",
      category: "catering",
      email: "info@gourmetcatering.com",
      phone: "(555) 567-8901",
      website: "www.gourmetcatering.com",
      rating: 4.6,
      priceRange: "$$$",
      description: "Full-service catering with customizable menus featuring locally-sourced ingredients and dietary accommodations.",
      _creationTime: Date.now() - 432000000,
    },
  ];

  const vendors = mockVendors;

  const categories = [
    { id: "venue", name: "Venues", icon: "🏛️" },
    { id: "catering", name: "Catering", icon: "🍽️" },
    { id: "photography", name: "Photography", icon: "📸" },
    { id: "flowers", name: "Flowers", icon: "💐" },
    { id: "music", name: "Music & DJ", icon: "🎵" },
    { id: "other", name: "Other", icon: "✨" },
  ];

  const filteredVendors = vendors.filter(vendor => {
    const matchesSearch = !searchTerm || 
      vendor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vendor.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vendor.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = !categoryFilter || vendor.category === categoryFilter;
    const matchesPrice = !priceFilter || vendor.priceRange === priceFilter;
    
    return matchesSearch && matchesCategory && matchesPrice;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Vendors</h1>
          <p className="text-gray-600">Discover and manage your wedding vendors</p>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-pink-500 hover:bg-pink-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors shadow-sm"
        >
          <PlusIcon className="w-5 h-5" />
          <span>Add Vendor</span>
        </button>
      </div>

      {/* Categories */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Categories</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((category) => {
            const count = vendors.filter(v => v.category === category.id).length;
            return (
              <button
                key={category.id}
                onClick={() => setCategoryFilter(categoryFilter === category.id ? "" : category.id)}
                className={`p-4 rounded-lg border-2 transition-all ${
                  categoryFilter === category.id
                    ? "border-pink-500 bg-pink-50"
                    : "border-gray-200 hover:border-gray-300"
                }`}
              >
                <div className="text-2xl mb-2">{category.icon}</div>
                <div className="text-sm font-medium text-gray-900">{category.name}</div>
                <div className="text-xs text-gray-500">{count} vendors</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search vendors, services, locations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
              />
            </div>
          </div>
          <select
            value={priceFilter}
            onChange={(e) => setPriceFilter(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
          >
            <option value="">All Prices</option>
            <option value="$">$ - Budget Friendly</option>
            <option value="$$">$$ - Moderate</option>
            <option value="$$$">$$$ - Premium</option>
            <option value="$$$$">$$$$ - Luxury</option>
          </select>
        </div>
      </div>

      {/* Vendors Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredVendors.length === 0 ? (
          <div className="col-span-full text-center py-12">
            <BuildingStorefrontIcon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No vendors found</h3>
            <p className="text-gray-500 mb-4">Try adjusting your search or filters.</p>
            <button
              onClick={() => {
                setSearchTerm("");
                setCategoryFilter("");
                setPriceFilter("");
              }}
              className="text-pink-600 hover:text-pink-700 font-medium"
            >
              Clear filters
            </button>
          </div>
        ) : (
          filteredVendors.map((vendor) => (
            <VendorCard key={vendor._id} vendor={vendor} />
          ))
        )}
      </div>

      {/* Add Vendor Modal */}
      {showAddForm && (
        <AddVendorModal onClose={() => setShowAddForm(false)} />
      )}
    </div>
  );
}

function VendorCard({ vendor }: { vendor: any }) {
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "venue": return "🏛️";
      case "catering": return "🍽️";
      case "photography": return "📸";
      case "flowers": return "💐";
      case "music": return "🎵";
      default: return "✨";
    }
  };

  const getPriceColor = (priceRange: string) => {
    switch (priceRange) {
      case "$": return "text-green-600 bg-green-100";
      case "$$": return "text-blue-600 bg-blue-100";
      case "$$$": return "text-purple-600 bg-purple-100";
      case "$$$$": return "text-pink-600 bg-pink-100";
      default: return "text-gray-600 bg-gray-100";
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <StarIconSolid
        key={i}
        className={`w-4 h-4 ${
          i < Math.floor(rating) ? "text-yellow-400" : "text-gray-300"
        }`}
      />
    ));
  };

  return (
    <div className="bg-white rounded-xl border border-gray-200 hover:shadow-lg transition-all duration-200 overflow-hidden">
      {/* Header */}
      <div className="p-6 pb-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center space-x-3">
            <div className="text-2xl">{getCategoryIcon(vendor.category)}</div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">{vendor.name}</h3>
              <div className="flex items-center space-x-2 mt-1">
                <div className="flex items-center space-x-1">
                  {renderStars(vendor.rating)}
                </div>
                <span className="text-sm text-gray-600">{vendor.rating}</span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriceColor(vendor.priceRange)}`}>
                  {vendor.priceRange}
                </span>
              </div>
            </div>
          </div>
          <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
            <EyeIcon className="w-5 h-5" />
          </button>
        </div>

        {/* Category */}
        <div className="flex items-center space-x-2 text-sm text-gray-600 mb-3">
          <TagIcon className="w-4 h-4" />
          <span className="capitalize">{vendor.category}</span>
        </div>

        {/* Description */}
        <p className="text-sm text-gray-600 mb-4 line-clamp-2">{vendor.description}</p>

        {/* Contact Info */}
        <div className="space-y-2">
          {vendor.email && (
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <EnvelopeIcon className="w-4 h-4" />
              <span className="truncate">{vendor.email}</span>
            </div>
          )}
          {vendor.phone && (
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <PhoneIcon className="w-4 h-4" />
              <span>{vendor.phone}</span>
            </div>
          )}
          {vendor.website && (
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <GlobeAltIcon className="w-4 h-4" />
              <a 
                href={`https://${vendor.website}`} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-pink-600 hover:text-pink-700 truncate"
              >
                {vendor.website}
              </a>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="px-6 py-3 bg-gray-50 border-t border-gray-200">
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-500">
            Added {new Date(vendor._creationTime).toLocaleDateString()}
          </span>
          <div className="flex space-x-1">
            <button className="p-1.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors">
              <PencilIcon className="w-4 h-4" />
            </button>
            <button className="p-1.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors">
              <TrashIcon className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function AddVendorModal({ onClose }: { onClose: () => void }) {
  const [formData, setFormData] = useState({
    name: "",
    category: "",
    email: "",
    phone: "",
    website: "",
    rating: "",
    priceRange: "",
    description: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement vendor creation when backend is ready
    console.log("Creating vendor:", formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Add New Vendor</h2>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Vendor Name *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Elegant Flowers Co."
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Category *
              </label>
              <select
                required
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
              >
                <option value="">Select category</option>
                <option value="venue">Venue</option>
                <option value="catering">Catering</option>
                <option value="photography">Photography</option>
                <option value="flowers">Flowers</option>
                <option value="music">Music & DJ</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="info@vendor.com"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Phone
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="(555) 123-4567"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Website
              </label>
              <input
                type="url"
                value={formData.website}
                onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                placeholder="www.vendor.com"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Rating
                </label>
                <select
                  value={formData.rating}
                  onChange={(e) => setFormData({ ...formData, rating: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
                >
                  <option value="">Select rating</option>
                  <option value="5">5 Stars</option>
                  <option value="4.5">4.5 Stars</option>
                  <option value="4">4 Stars</option>
                  <option value="3.5">3.5 Stars</option>
                  <option value="3">3 Stars</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Price Range
                </label>
                <select
                  value={formData.priceRange}
                  onChange={(e) => setFormData({ ...formData, priceRange: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
                >
                  <option value="">Select price range</option>
                  <option value="$">$ - Budget Friendly</option>
                  <option value="$$">$$ - Moderate</option>
                  <option value="$$$">$$$ - Premium</option>
                  <option value="$$$$">$$$$ - Luxury</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description
              </label>
              <textarea
                rows={3}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe the vendor's services and specialties..."
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
              />
            </div>

            <div className="flex space-x-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 px-4 py-2 bg-pink-500 text-white rounded-lg hover:bg-pink-600 transition-colors"
              >
                Add Vendor
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
