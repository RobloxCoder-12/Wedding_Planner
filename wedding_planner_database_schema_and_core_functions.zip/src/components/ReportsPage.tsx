import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { 
  ChartBarIcon,
  CalendarIcon,
  CurrencyDollarIcon,
  UsersIcon,
  ArrowTrendingUpIcon,
  ArrowTrendingDownIcon,
  DocumentArrowDownIcon,
  FunnelIcon
} from "@heroicons/react/24/outline";

export function ReportsPage() {
  const [dateRange, setDateRange] = useState("30");
  const [reportType, setReportType] = useState("overview");

  const clientStats = useQuery(api.clients.getStats);
  const projectStats = useQuery(api.projects.getStats);
  const leadStats = useQuery(api.leads.getStats);

  if (!clientStats || !projectStats || !leadStats) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-pink-500"></div>
      </div>
    );
  }

  const totalRevenue = projectStats.revenue;
  const averageProjectValue = projectStats.total > 0 ? totalRevenue / projectStats.total : 0;
  const conversionRate = leadStats.conversionRate;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Reports & Analytics</h1>
          <p className="text-gray-600">Track your business performance and growth</p>
        </div>
        <div className="flex items-center space-x-3">
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
          >
            <option value="7">Last 7 days</option>
            <option value="30">Last 30 days</option>
            <option value="90">Last 90 days</option>
            <option value="365">Last year</option>
          </select>
          <button className="bg-pink-500 hover:bg-pink-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors">
            <DocumentArrowDownIcon className="w-5 h-5" />
            <span>Export</span>
          </button>
        </div>
      </div>

      {/* Report Type Tabs */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex space-x-1 bg-gray-100 rounded-lg p-1">
          <button
            onClick={() => setReportType("overview")}
            className={`flex-1 px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              reportType === "overview" ? "bg-white text-gray-900 shadow-sm" : "text-gray-600"
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setReportType("revenue")}
            className={`flex-1 px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              reportType === "revenue" ? "bg-white text-gray-900 shadow-sm" : "text-gray-600"
            }`}
          >
            Revenue
          </button>
          <button
            onClick={() => setReportType("clients")}
            className={`flex-1 px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              reportType === "clients" ? "bg-white text-gray-900 shadow-sm" : "text-gray-600"
            }`}
          >
            Clients
          </button>
          <button
            onClick={() => setReportType("leads")}
            className={`flex-1 px-4 py-2 text-sm font-medium rounded-md transition-colors ${
              reportType === "leads" ? "bg-white text-gray-900 shadow-sm" : "text-gray-600"
            }`}
          >
            Leads
          </button>
        </div>
      </div>

      {reportType === "overview" && (
        <OverviewReport 
          clientStats={clientStats}
          projectStats={projectStats}
          leadStats={leadStats}
          totalRevenue={totalRevenue}
          averageProjectValue={averageProjectValue}
          conversionRate={conversionRate}
        />
      )}

      {reportType === "revenue" && (
        <RevenueReport 
          projectStats={projectStats}
          totalRevenue={totalRevenue}
          averageProjectValue={averageProjectValue}
        />
      )}

      {reportType === "clients" && (
        <ClientsReport clientStats={clientStats} />
      )}

      {reportType === "leads" && (
        <LeadsReport leadStats={leadStats} conversionRate={conversionRate} />
      )}
    </div>
  );
}

function OverviewReport({ 
  clientStats, 
  projectStats, 
  leadStats, 
  totalRevenue, 
  averageProjectValue, 
  conversionRate 
}: any) {
  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Total Revenue"
          value={`$${totalRevenue.toLocaleString()}`}
          change="+12.5%"
          trend="up"
          icon={CurrencyDollarIcon}
          color="green"
        />
        <MetricCard
          title="Active Projects"
          value={projectStats.active}
          change="+8.2%"
          trend="up"
          icon={ChartBarIcon}
          color="blue"
        />
        <MetricCard
          title="Total Clients"
          value={clientStats.total}
          change="+15.3%"
          trend="up"
          icon={UsersIcon}
          color="purple"
        />
        <MetricCard
          title="Conversion Rate"
          value={`${conversionRate}%`}
          change="-2.1%"
          trend="down"
          icon={FunnelIcon}
          color="pink"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Chart */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Revenue Trend</h3>
          <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
            <div className="text-center">
              <ChartBarIcon className="w-12 h-12 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-500">Revenue chart visualization</p>
              <p className="text-sm text-gray-400">Chart component would go here</p>
            </div>
          </div>
        </div>

        {/* Project Status Distribution */}
        <div className="bg-white rounded-xl border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Project Status</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Planning</span>
              <div className="flex items-center space-x-2">
                <div className="w-32 bg-gray-200 rounded-full h-2">
                  <div className="bg-yellow-500 h-2 rounded-full" style={{ width: "40%" }}></div>
                </div>
                <span className="text-sm font-medium text-gray-900">40%</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">In Progress</span>
              <div className="flex items-center space-x-2">
                <div className="w-32 bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-500 h-2 rounded-full" style={{ width: "35%" }}></div>
                </div>
                <span className="text-sm font-medium text-gray-900">35%</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Completed</span>
              <div className="flex items-center space-x-2">
                <div className="w-32 bg-gray-200 rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full" style={{ width: "25%" }}></div>
                </div>
                <span className="text-sm font-medium text-gray-900">25%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Performance Summary */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">${averageProjectValue.toLocaleString()}</div>
            <div className="text-sm text-gray-600">Average Project Value</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">{Math.round(projectStats.total / 12)}</div>
            <div className="text-sm text-gray-600">Projects per Month</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-900">{leadStats.total}</div>
            <div className="text-sm text-gray-600">Total Leads Generated</div>
          </div>
        </div>
      </div>
    </div>
  );
}

function RevenueReport({ projectStats, totalRevenue, averageProjectValue }: any) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <MetricCard
          title="Total Revenue"
          value={`$${totalRevenue.toLocaleString()}`}
          change="+12.5%"
          trend="up"
          icon={CurrencyDollarIcon}
          color="green"
        />
        <MetricCard
          title="Average Project Value"
          value={`$${averageProjectValue.toLocaleString()}`}
          change="+5.2%"
          trend="up"
          icon={ChartBarIcon}
          color="blue"
        />
        <MetricCard
          title="Monthly Revenue"
          value={`$${Math.round(totalRevenue / 12).toLocaleString()}`}
          change="+8.7%"
          trend="up"
          icon={CalendarIcon}
          color="purple"
        />
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Revenue Breakdown</h3>
        <div className="h-80 flex items-center justify-center bg-gray-50 rounded-lg">
          <div className="text-center">
            <ChartBarIcon className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 text-lg">Revenue Analytics Chart</p>
            <p className="text-sm text-gray-400">Detailed revenue visualization would be displayed here</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function ClientsReport({ clientStats }: any) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <MetricCard
          title="Total Clients"
          value={clientStats.total}
          change="+15.3%"
          trend="up"
          icon={UsersIcon}
          color="blue"
        />
        <MetricCard
          title="Active Clients"
          value={clientStats.active}
          change="+22.1%"
          trend="up"
          icon={UsersIcon}
          color="green"
        />
        <MetricCard
          title="Completed Projects"
          value={clientStats.completed}
          change="+18.5%"
          trend="up"
          icon={UsersIcon}
          color="purple"
        />
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Client Growth</h3>
        <div className="h-80 flex items-center justify-center bg-gray-50 rounded-lg">
          <div className="text-center">
            <UsersIcon className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 text-lg">Client Analytics Chart</p>
            <p className="text-sm text-gray-400">Client growth and retention metrics would be displayed here</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function LeadsReport({ leadStats, conversionRate }: any) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <MetricCard
          title="Total Leads"
          value={leadStats.total}
          change="+25.8%"
          trend="up"
          icon={FunnelIcon}
          color="blue"
        />
        <MetricCard
          title="Conversion Rate"
          value={`${conversionRate}%`}
          change="-2.1%"
          trend="down"
          icon={ArrowTrendingUpIcon}
          color="green"
        />
        <MetricCard
          title="New Leads"
          value={leadStats.new}
          change="+12.3%"
          trend="up"
          icon={UsersIcon}
          color="purple"
        />
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Lead Funnel</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
            <span className="font-medium text-blue-900">New Leads</span>
            <span className="text-2xl font-bold text-blue-900">{leadStats.new}</span>
          </div>
          <div className="flex items-center justify-between p-4 bg-yellow-50 rounded-lg">
            <span className="font-medium text-yellow-900">Contacted</span>
            <span className="text-2xl font-bold text-yellow-900">{Math.round(leadStats.new * 0.7)}</span>
          </div>
          <div className="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
            <span className="font-medium text-purple-900">Proposal Sent</span>
            <span className="text-2xl font-bold text-purple-900">{Math.round(leadStats.new * 0.4)}</span>
          </div>
          <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
            <span className="font-medium text-green-900">Converted</span>
            <span className="text-2xl font-bold text-green-900">{leadStats.converted}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, change, trend, icon: Icon, color }: {
  title: string;
  value: string | number;
  change: string;
  trend: "up" | "down";
  icon: any;
  color: "green" | "blue" | "purple" | "pink";
}) {
  const colorClasses = {
    green: "bg-green-50 text-green-700 border-green-200",
    blue: "bg-blue-50 text-blue-700 border-blue-200",
    purple: "bg-purple-50 text-purple-700 border-purple-200",
    pink: "bg-pink-50 text-pink-700 border-pink-200",
  };

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="text-2xl font-bold text-gray-900 mt-2">{value}</p>
        </div>
        <div className={`p-3 rounded-lg border ${colorClasses[color]}`}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
      <div className="mt-4 flex items-center">
        {trend === "up" ? (
          <ArrowTrendingUpIcon className="w-4 h-4 text-green-500 mr-1" />
        ) : (
          <ArrowTrendingDownIcon className="w-4 h-4 text-red-500 mr-1" />
        )}
        <span className={`text-sm font-medium ${trend === "up" ? "text-green-600" : "text-red-600"}`}>
          {change}
        </span>
        <span className="text-sm text-gray-500 ml-1">vs last period</span>
      </div>
    </div>
  );
}
