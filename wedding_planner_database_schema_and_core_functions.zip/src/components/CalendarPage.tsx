import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { 
  ChevronLeftIcon, 
  ChevronRightIcon,
  PlusIcon,
  CalendarDaysIcon,
  ClockIcon,
  MapPinIcon,
  UserIcon
} from "@heroicons/react/24/outline";

export function CalendarPage() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<"month" | "week" | "day">("month");
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  const projects = useQuery(api.projects.list, {});

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);
  const firstDayOfWeek = firstDayOfMonth.getDay();
  const daysInMonth = lastDayOfMonth.getDate();

  const previousMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const getEventsForDate = (date: Date) => {
    if (!projects) return [];
    
    const dateStr = date.toISOString().split('T')[0];
    return projects.filter(project => 
      project.weddingDate === dateStr
    );
  };

  const renderCalendarDays = () => {
    const days = [];
    const today = new Date();
    
    // Empty cells for days before the first day of the month
    for (let i = 0; i < firstDayOfWeek; i++) {
      days.push(
        <div key={`empty-${i}`} className="h-32 bg-gray-50 border border-gray-200"></div>
      );
    }

    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day);
      const isToday = 
        day === today.getDate() && 
        month === today.getMonth() && 
        year === today.getFullYear();
      
      const events = getEventsForDate(date);

      days.push(
        <div
          key={day}
          className={`h-32 border border-gray-200 p-2 cursor-pointer hover:bg-gray-50 transition-colors ${
            isToday ? "bg-pink-50 border-pink-200" : "bg-white"
          }`}
          onClick={() => setSelectedDate(date)}
        >
          <div className={`text-sm font-medium mb-1 ${
            isToday ? "text-pink-600" : "text-gray-900"
          }`}>
            {day}
          </div>
          <div className="space-y-1">
            {events.slice(0, 2).map((event) => (
              <div
                key={event._id}
                className="text-xs p-1 bg-pink-100 text-pink-800 rounded truncate"
              >
                {event.title}
              </div>
            ))}
            {events.length > 2 && (
              <div className="text-xs text-gray-500">
                +{events.length - 2} more
              </div>
            )}
          </div>
        </div>
      );
    }

    return days;
  };

  const upcomingEvents = projects?.filter(project => {
    const weddingDate = new Date(project.weddingDate);
    const now = new Date();
    return weddingDate >= now;
  }).sort((a, b) => new Date(a.weddingDate).getTime() - new Date(b.weddingDate).getTime()).slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Calendar</h1>
          <p className="text-gray-600">Manage your wedding events and timeline</p>
        </div>
        <div className="flex items-center space-x-3">
          <div className="flex bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setViewMode("month")}
              className={`px-3 py-1 text-sm font-medium rounded-md transition-colors ${
                viewMode === "month" ? "bg-white text-gray-900 shadow-sm" : "text-gray-600"
              }`}
            >
              Month
            </button>
            <button
              onClick={() => setViewMode("week")}
              className={`px-3 py-1 text-sm font-medium rounded-md transition-colors ${
                viewMode === "week" ? "bg-white text-gray-900 shadow-sm" : "text-gray-600"
              }`}
            >
              Week
            </button>
            <button
              onClick={() => setViewMode("day")}
              className={`px-3 py-1 text-sm font-medium rounded-md transition-colors ${
                viewMode === "day" ? "bg-white text-gray-900 shadow-sm" : "text-gray-600"
              }`}
            >
              Day
            </button>
          </div>
          <button className="bg-pink-500 hover:bg-pink-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors">
            <PlusIcon className="w-5 h-5" />
            <span>Add Event</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main Calendar */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
            {/* Calendar Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <div className="flex items-center space-x-4">
                <h2 className="text-xl font-semibold text-gray-900">
                  {monthNames[month]} {year}
                </h2>
                <div className="flex space-x-1">
                  <button
                    onClick={previousMonth}
                    className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <ChevronLeftIcon className="w-5 h-5 text-gray-600" />
                  </button>
                  <button
                    onClick={nextMonth}
                    className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <ChevronRightIcon className="w-5 h-5 text-gray-600" />
                  </button>
                </div>
              </div>
              <button
                onClick={() => setCurrentDate(new Date())}
                className="px-3 py-1 text-sm text-pink-600 hover:bg-pink-50 rounded-lg transition-colors"
              >
                Today
              </button>
            </div>

            {/* Calendar Grid */}
            <div className="grid grid-cols-7">
              {/* Day Headers */}
              {dayNames.map((day) => (
                <div key={day} className="p-4 text-center border-b border-gray-200 bg-gray-50">
                  <span className="text-sm font-medium text-gray-600">{day}</span>
                </div>
              ))}
              
              {/* Calendar Days */}
              {renderCalendarDays()}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Mini Calendar */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick View</h3>
            <div className="grid grid-cols-7 gap-1 mb-2">
              {["S", "M", "T", "W", "T", "F", "S"].map((day, i) => (
                <div key={i} className="h-8 flex items-center justify-center">
                  <span className="text-xs font-medium text-gray-500">{day}</span>
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-1">
              {Array.from({ length: 35 }, (_, i) => {
                const day = i - firstDayOfWeek + 1;
                const isCurrentMonth = day > 0 && day <= daysInMonth;
                const date = new Date(year, month, day);
                const isToday = isCurrentMonth && 
                  day === new Date().getDate() && 
                  month === new Date().getMonth() && 
                  year === new Date().getFullYear();
                const hasEvents = isCurrentMonth && getEventsForDate(date).length > 0;

                return (
                  <button
                    key={i}
                    className={`h-8 w-8 text-xs font-medium rounded transition-colors ${
                      !isCurrentMonth 
                        ? "text-gray-300" 
                        : isToday
                        ? "bg-pink-500 text-white"
                        : hasEvents
                        ? "bg-pink-100 text-pink-700"
                        : "text-gray-700 hover:bg-gray-100"
                    }`}
                  >
                    {isCurrentMonth ? day : ""}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Upcoming Events */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Upcoming Weddings</h3>
            <div className="space-y-3">
              {upcomingEvents && upcomingEvents.length > 0 ? (
                upcomingEvents.map((event) => {
                  const daysUntil = Math.ceil(
                    (new Date(event.weddingDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
                  );
                  
                  return (
                    <div key={event._id} className="p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <div className="w-3 h-3 bg-pink-500 rounded-full mt-1.5"></div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {event.title}
                          </p>
                          <div className="flex items-center space-x-1 mt-1">
                            <UserIcon className="w-3 h-3 text-gray-400" />
                            <span className="text-xs text-gray-600">{event.client?.name}</span>
                          </div>
                          <div className="flex items-center space-x-1 mt-1">
                            <MapPinIcon className="w-3 h-3 text-gray-400" />
                            <span className="text-xs text-gray-600 truncate">{event.venue}</span>
                          </div>
                          <div className="flex items-center space-x-1 mt-1">
                            <ClockIcon className="w-3 h-3 text-gray-400" />
                            <span className="text-xs text-gray-600">
                              {daysUntil === 0 ? "Today" : 
                               daysUntil === 1 ? "Tomorrow" : 
                               `${daysUntil} days`}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-4">
                  <CalendarDaysIcon className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-500">No upcoming weddings</p>
                </div>
              )}
            </div>
          </div>

          {/* Event Legend */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Legend</h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-pink-500 rounded"></div>
                <span className="text-sm text-gray-600">Wedding Events</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-500 rounded"></div>
                <span className="text-sm text-gray-600">Vendor Meetings</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded"></div>
                <span className="text-sm text-gray-600">Client Consultations</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-yellow-500 rounded"></div>
                <span className="text-sm text-gray-600">Deadlines</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Selected Date Modal */}
      {selectedDate && (
        <DateDetailModal 
          date={selectedDate}
          events={getEventsForDate(selectedDate)}
          onClose={() => setSelectedDate(null)}
        />
      )}
    </div>
  );
}

function DateDetailModal({ date, events, onClose }: { 
  date: Date; 
  events: any[]; 
  onClose: () => void; 
}) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-md w-full">
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">
              {date.toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </h2>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
            >
              ✕
            </button>
          </div>

          <div className="space-y-3">
            {events.length > 0 ? (
              events.map((event) => (
                <div key={event._id} className="p-4 bg-pink-50 rounded-lg border border-pink-200">
                  <h3 className="font-medium text-gray-900">{event.title}</h3>
                  <div className="mt-2 space-y-1">
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <UserIcon className="w-4 h-4" />
                      <span>{event.client?.name}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <MapPinIcon className="w-4 h-4" />
                      <span>{event.venue}</span>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8">
                <CalendarDaysIcon className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-500">No events scheduled for this date</p>
                <button className="mt-3 text-pink-600 hover:text-pink-700 text-sm font-medium">
                  Add Event
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
