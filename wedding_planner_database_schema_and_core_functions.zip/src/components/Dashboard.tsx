import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { KpiCard } from "./KpiCard";
import { ActivityFeed } from "./ActivityFeed";
import { MiniCalendar } from "./MiniCalendar";
import { UpcomingTimeline } from "./UpcomingTimeline";

export function Dashboard() {
  const clientStats = useQuery(api.clients.getStats);
  const projectStats = useQuery(api.projects.getStats);
  const leadStats = useQuery(api.leads.getStats);

  if (!clientStats || !projectStats || !leadStats) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-pink-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Welcome Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Good morning! 👋</h1>
        <p className="text-gray-600 mt-2">Here's what's happening with your weddings today.</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <KpiCard
          title="Total Clients"
          value={clientStats.total}
          delta={`${clientStats.active} active`}
          trend="up"
          color="blue"
        />
        <KpiCard
          title="Active Projects"
          value={projectStats.active}
          delta={`${projectStats.completed} completed`}
          trend="up"
          color="green"
        />
        <KpiCard
          title="Total Revenue"
          value={`$${projectStats.revenue.toLocaleString()}`}
          delta="This year"
          trend="up"
          color="purple"
        />
        <KpiCard
          title="Lead Conversion"
          value={`${leadStats.conversionRate}%`}
          delta={`${leadStats.new} new leads`}
          trend="up"
          color="pink"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - Activity Feed */}
        <div className="lg:col-span-2">
          <ActivityFeed />
        </div>

        {/* Right Column - Calendar & Timeline */}
        <div className="space-y-6">
          <MiniCalendar />
          <UpcomingTimeline />
        </div>
      </div>
    </div>
  );
}
