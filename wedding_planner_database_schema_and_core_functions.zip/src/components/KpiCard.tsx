import { ArrowUpIcon, ArrowDownIcon } from "@heroicons/react/24/solid";

interface KpiCardProps {
  title: string;
  value: string | number;
  delta: string;
  trend: "up" | "down";
  color: "blue" | "green" | "purple" | "pink";
}

const colorClasses = {
  blue: "bg-blue-50 text-blue-700 border-blue-200",
  green: "bg-green-50 text-green-700 border-green-200",
  purple: "bg-purple-50 text-purple-700 border-purple-200",
  pink: "bg-pink-50 text-pink-700 border-pink-200",
};

export function KpiCard({ title, value, delta, trend, color }: KpiCardProps) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="text-2xl font-bold text-gray-900 mt-2">{value}</p>
        </div>
        <div className={`p-3 rounded-lg ${colorClasses[color]}`}>
          {trend === "up" ? (
            <ArrowUpIcon className="w-5 h-5" />
          ) : (
            <ArrowDownIcon className="w-5 h-5" />
          )}
        </div>
      </div>
      <div className="mt-4 flex items-center">
        <span className="text-sm text-gray-500">{delta}</span>
      </div>
    </div>
  );
}
