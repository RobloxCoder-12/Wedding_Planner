import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { 
  PlusIcon, 
  MagnifyingGlassIcon,
  UserPlusIcon,
  PhoneIcon,
  EnvelopeIcon,
  CalendarIcon,
  CurrencyDollarIcon,
  MapPinIcon,
  ClockIcon,
  CheckCircleIcon,
  XCircleIcon,
  ExclamationTriangleIcon,
  EyeIcon,
  PencilIcon,
  ArrowRightIcon
} from "@heroicons/react/24/outline";
import { Id } from "../../convex/_generated/dataModel";

export function LeadsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedLead, setSelectedLead] = useState<any>(null);

  const leads = useQuery(api.leads.list, { 
    status: statusFilter || undefined 
  });

  const filteredLeads = leads?.filter(lead => 
    !searchTerm || 
    lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    lead.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (lead.venue && lead.venue.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  if (!leads) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-pink-500"></div>
      </div>
    );
  }

  const statusCounts = {
    new: leads.filter(l => l.status === "new").length,
    contacted: leads.filter(l => l.status === "contacted").length,
    proposal: leads.filter(l => l.status === "proposal").length,
    booked: leads.filter(l => l.status === "booked").length,
    lost: leads.filter(l => l.status === "lost").length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Leads</h1>
          <p className="text-gray-600">Track and convert potential clients</p>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-pink-500 hover:bg-pink-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors shadow-sm"
        >
          <PlusIcon className="w-5 h-5" />
          <span>Add Lead</span>
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <UserPlusIcon className="w-5 h-5 text-blue-600" />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-600">New</p>
              <p className="text-xl font-bold text-gray-900">{statusCounts.new}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center">
            <div className="p-2 bg-yellow-100 rounded-lg">
              <ClockIcon className="w-5 h-5 text-yellow-600" />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-600">Contacted</p>
              <p className="text-xl font-bold text-gray-900">{statusCounts.contacted}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center">
            <div className="p-2 bg-purple-100 rounded-lg">
              <ExclamationTriangleIcon className="w-5 h-5 text-purple-600" />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-600">Proposal</p>
              <p className="text-xl font-bold text-gray-900">{statusCounts.proposal}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center">
            <div className="p-2 bg-green-100 rounded-lg">
              <CheckCircleIcon className="w-5 h-5 text-green-600" />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-600">Booked</p>
              <p className="text-xl font-bold text-gray-900">{statusCounts.booked}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center">
            <div className="p-2 bg-red-100 rounded-lg">
              <XCircleIcon className="w-5 h-5 text-red-600" />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-600">Lost</p>
              <p className="text-xl font-bold text-gray-900">{statusCounts.lost}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search leads by name, email, or venue..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
              />
            </div>
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
          >
            <option value="">All Status</option>
            <option value="new">New</option>
            <option value="contacted">Contacted</option>
            <option value="proposal">Proposal</option>
            <option value="booked">Booked</option>
            <option value="lost">Lost</option>
          </select>
        </div>
      </div>

      {/* Leads Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredLeads && filteredLeads.length === 0 ? (
          <div className="col-span-full text-center py-12">
            <UserPlusIcon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No leads found</h3>
            <p className="text-gray-500 mb-4">Start building your client pipeline by adding leads.</p>
            <button
              onClick={() => setShowAddForm(true)}
              className="bg-pink-500 hover:bg-pink-600 text-white px-4 py-2 rounded-lg transition-colors"
            >
              Add First Lead
            </button>
          </div>
        ) : (
          filteredLeads?.map((lead) => (
            <LeadCard 
              key={lead._id} 
              lead={lead} 
              onView={() => setSelectedLead(lead)}
            />
          ))
        )}
      </div>

      {/* Add Lead Modal */}
      {showAddForm && (
        <AddLeadModal onClose={() => setShowAddForm(false)} />
      )}

      {/* Lead Detail Modal */}
      {selectedLead && (
        <LeadDetailModal 
          lead={selectedLead}
          onClose={() => setSelectedLead(null)}
        />
      )}
    </div>
  );
}

function LeadCard({ lead, onView }: { lead: any; onView: () => void }) {
  const updateLeadStatus = useMutation(api.leads.updateStatus);
  const convertToClient = useMutation(api.leads.convertToClient);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "contacted":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "proposal":
        return "bg-purple-100 text-purple-800 border-purple-200";
      case "booked":
        return "bg-green-100 text-green-800 border-green-200";
      case "lost":
        return "bg-red-100 text-red-800 border-red-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getNextStatus = (currentStatus: string) => {
    switch (currentStatus) {
      case "new": return "contacted";
      case "contacted": return "proposal";
      case "proposal": return "booked";
      default: return null;
    }
  };

  const handleStatusUpdate = async (newStatus: string) => {
    try {
      await updateLeadStatus({ id: lead._id, status: newStatus });
    } catch (error) {
      console.error("Failed to update lead status:", error);
    }
  };

  const handleConvertToClient = async () => {
    if (lead.estimatedBudget) {
      try {
        await convertToClient({ id: lead._id, budget: lead.estimatedBudget });
      } catch (error) {
        console.error("Failed to convert lead:", error);
      }
    }
  };

  const nextStatus = getNextStatus(lead.status);
  const daysSinceCreated = Math.floor(
    (Date.now() - lead._creationTime) / (1000 * 60 * 60 * 24)
  );

  return (
    <div className="bg-white rounded-xl border border-gray-200 hover:shadow-lg transition-all duration-200 overflow-hidden">
      {/* Header */}
      <div className="p-6 pb-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-gray-900 mb-1">{lead.name}</h3>
            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getStatusColor(lead.status)}`}>
              {lead.status}
            </span>
          </div>
          <button
            onClick={onView}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <EyeIcon className="w-5 h-5" />
          </button>
        </div>

        {/* Contact Info */}
        <div className="space-y-2 mb-4">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <EnvelopeIcon className="w-4 h-4" />
            <span className="truncate">{lead.email}</span>
          </div>
          {lead.phone && (
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <PhoneIcon className="w-4 h-4" />
              <span>{lead.phone}</span>
            </div>
          )}
        </div>

        {/* Wedding Details */}
        {lead.weddingDate && (
          <div className="flex items-center space-x-2 text-sm text-gray-600 mb-2">
            <CalendarIcon className="w-4 h-4" />
            <span>{new Date(lead.weddingDate).toLocaleDateString()}</span>
          </div>
        )}

        {lead.venue && (
          <div className="flex items-center space-x-2 text-sm text-gray-600 mb-2">
            <MapPinIcon className="w-4 h-4" />
            <span className="truncate">{lead.venue}</span>
          </div>
        )}

        {lead.estimatedBudget && (
          <div className="flex items-center space-x-2 text-sm text-gray-600 mb-4">
            <CurrencyDollarIcon className="w-4 h-4" />
            <span>${lead.estimatedBudget.toLocaleString()}</span>
          </div>
        )}

        {/* Source */}
        {lead.source && (
          <div className="mb-4">
            <span className="inline-block px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">
              Source: {lead.source}
            </span>
          </div>
        )}

        {/* Notes */}
        {lead.notes && (
          <p className="text-sm text-gray-600 mb-4 line-clamp-2">{lead.notes}</p>
        )}
      </div>

      {/* Actions */}
      <div className="px-6 py-3 bg-gray-50 border-t border-gray-200">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-gray-500">
            {daysSinceCreated === 0 ? "Today" : `${daysSinceCreated} days ago`}
          </span>
          {lead.lastContactDate && (
            <span className="text-xs text-gray-500">
              Last contact: {new Date(lead.lastContactDate).toLocaleDateString()}
            </span>
          )}
        </div>
        
        <div className="flex space-x-2">
          {nextStatus && (
            <button
              onClick={() => handleStatusUpdate(nextStatus)}
              className="flex-1 px-3 py-1.5 bg-pink-500 text-white text-sm rounded-lg hover:bg-pink-600 transition-colors flex items-center justify-center space-x-1"
            >
              <span>Move to {nextStatus}</span>
              <ArrowRightIcon className="w-3 h-3" />
            </button>
          )}
          
          {lead.status === "proposal" && lead.estimatedBudget && (
            <button
              onClick={handleConvertToClient}
              className="flex-1 px-3 py-1.5 bg-green-500 text-white text-sm rounded-lg hover:bg-green-600 transition-colors"
            >
              Convert to Client
            </button>
          )}
          
          {lead.status !== "lost" && (
            <button
              onClick={() => handleStatusUpdate("lost")}
              className="px-3 py-1.5 border border-gray-300 text-gray-700 text-sm rounded-lg hover:bg-gray-50 transition-colors"
            >
              Mark Lost
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function AddLeadModal({ onClose }: { onClose: () => void }) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    weddingDate: "",
    venue: "",
    estimatedBudget: "",
    source: "",
    notes: "",
  });

  const createLead = useMutation(api.leads.create);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      await createLead({
        name: formData.name,
        email: formData.email,
        phone: formData.phone || undefined,
        weddingDate: formData.weddingDate || undefined,
        venue: formData.venue || undefined,
        estimatedBudget: formData.estimatedBudget ? Number(formData.estimatedBudget) : undefined,
        source: formData.source || undefined,
        notes: formData.notes || undefined,
      });
      
      onClose();
    } catch (error) {
      console.error("Failed to create lead:", error);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Add New Lead</h2>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Name *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Sarah Johnson"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email *
              </label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="sarah@example.com"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Phone
              </label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="(555) 123-4567"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Wedding Date
              </label>
              <input
                type="date"
                value={formData.weddingDate}
                onChange={(e) => setFormData({ ...formData, weddingDate: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Venue
              </label>
              <input
                type="text"
                value={formData.venue}
                onChange={(e) => setFormData({ ...formData, venue: e.target.value })}
                placeholder="e.g., Grand Ballroom Hotel"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Estimated Budget
              </label>
              <input
                type="number"
                value={formData.estimatedBudget}
                onChange={(e) => setFormData({ ...formData, estimatedBudget: e.target.value })}
                placeholder="50000"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Source
              </label>
              <select
                value={formData.source}
                onChange={(e) => setFormData({ ...formData, source: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
              >
                <option value="">Select source</option>
                <option value="website">Website</option>
                <option value="referral">Referral</option>
                <option value="social">Social Media</option>
                <option value="advertising">Advertising</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Notes
              </label>
              <textarea
                rows={3}
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Additional information about the lead..."
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
              />
            </div>

            <div className="flex space-x-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 px-4 py-2 bg-pink-500 text-white rounded-lg hover:bg-pink-600 transition-colors"
              >
                Add Lead
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

function LeadDetailModal({ lead, onClose }: { lead: any; onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-semibold text-gray-900">{lead.name}</h2>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
            >
              ✕
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Contact Information</h3>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 text-sm">
                    <EnvelopeIcon className="w-4 h-4 text-gray-400" />
                    <span>{lead.email}</span>
                  </div>
                  {lead.phone && (
                    <div className="flex items-center space-x-2 text-sm">
                      <PhoneIcon className="w-4 h-4 text-gray-400" />
                      <span>{lead.phone}</span>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Wedding Details</h3>
                <div className="space-y-2">
                  {lead.weddingDate && (
                    <div className="flex items-center space-x-2 text-sm">
                      <CalendarIcon className="w-4 h-4 text-gray-400" />
                      <span>{new Date(lead.weddingDate).toLocaleDateString()}</span>
                    </div>
                  )}
                  {lead.venue && (
                    <div className="flex items-center space-x-2 text-sm">
                      <MapPinIcon className="w-4 h-4 text-gray-400" />
                      <span>{lead.venue}</span>
                    </div>
                  )}
                  {lead.estimatedBudget && (
                    <div className="flex items-center space-x-2 text-sm">
                      <CurrencyDollarIcon className="w-4 h-4 text-gray-400" />
                      <span>${lead.estimatedBudget.toLocaleString()}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Lead Information</h3>
                <div className="space-y-2">
                  <div className="text-sm">
                    <span className="text-gray-600">Status:</span>
                    <span className="ml-2 capitalize">{lead.status}</span>
                  </div>
                  {lead.source && (
                    <div className="text-sm">
                      <span className="text-gray-600">Source:</span>
                      <span className="ml-2 capitalize">{lead.source}</span>
                    </div>
                  )}
                  <div className="text-sm">
                    <span className="text-gray-600">Created:</span>
                    <span className="ml-2">{new Date(lead._creationTime).toLocaleDateString()}</span>
                  </div>
                  {lead.lastContactDate && (
                    <div className="text-sm">
                      <span className="text-gray-600">Last Contact:</span>
                      <span className="ml-2">{new Date(lead.lastContactDate).toLocaleDateString()}</span>
                    </div>
                  )}
                </div>
              </div>

              {lead.notes && (
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Notes</h3>
                  <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                    {lead.notes}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
