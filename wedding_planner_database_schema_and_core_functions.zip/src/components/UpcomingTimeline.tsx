export function UpcomingTimeline() {
  // Mock data for upcoming events
  const upcomingEvents = [
    {
      id: 1,
      title: "Venue walkthrough",
      client: "Sarah & Mike",
      date: "Today, 2:00 PM",
      type: "venue",
    },
    {
      id: 2,
      title: "Cake tasting",
      client: "Emma & James",
      date: "Tomorrow, 10:00 AM",
      type: "catering",
    },
    {
      id: 3,
      title: "Final dress fitting",
      client: "Lisa & David",
      date: "Friday, 3:00 PM",
      type: "attire",
    },
    {
      id: 4,
      title: "Rehearsal dinner",
      client: "Sarah & Mike",
      date: "Saturday, 6:00 PM",
      type: "event",
    },
  ];

  const getEventColor = (type: string) => {
    switch (type) {
      case "venue":
        return "bg-blue-100 text-blue-700";
      case "catering":
        return "bg-green-100 text-green-700";
      case "attire":
        return "bg-purple-100 text-purple-700";
      case "event":
        return "bg-pink-100 text-pink-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-6">Upcoming Events</h3>
      <div className="space-y-4">
        {upcomingEvents.map((event) => (
          <div key={event.id} className="flex items-start space-x-3">
            <div className={`w-3 h-3 rounded-full mt-2 ${getEventColor(event.type).split(' ')[0]}`}></div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900">{event.title}</p>
              <p className="text-sm text-gray-600">{event.client}</p>
              <p className="text-xs text-gray-500 mt-1">{event.date}</p>
            </div>
          </div>
        ))}
      </div>
      <button className="w-full mt-4 text-sm text-pink-600 hover:text-pink-700 font-medium">
        View all events →
      </button>
    </div>
  );
}
