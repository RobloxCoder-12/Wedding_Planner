import { 
  HomeIcon, 
  UsersIcon, 
  BriefcaseIcon, 
  CalendarIcon, 
  BuildingStorefrontIcon,
  UserPlusIcon,
  ChartBarIcon,
  PlusIcon,
  Bars3Icon,
  XMarkIcon
} from "@heroicons/react/24/outline";

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
  currentView: string;
  onViewChange: (view: string) => void;
}

const navigation = [
  { name: "Dashboard", id: "dashboard", icon: HomeIcon },
  { name: "Clients", id: "clients", icon: UsersIcon },
  { name: "Projects", id: "projects", icon: BriefcaseIcon },
  { name: "Calendar", id: "calendar", icon: CalendarIcon },
  { name: "Vendors", id: "vendors", icon: BuildingStorefrontIcon },
  { name: "Leads", id: "leads", icon: UserPlusIcon },
  { name: "Reports", id: "reports", icon: ChartBarIcon },
];

export function Sidebar({ collapsed, onToggle, currentView, onViewChange }: SidebarProps) {
  return (
    <div className={`bg-white border-r border-gray-200 transition-all duration-300 ${collapsed ? 'w-20' : 'w-72'}`}>
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          {!collapsed && (
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-pink-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">EA</span>
              </div>
              <span className="text-xl font-semibold text-gray-900">EverAfter</span>
            </div>
          )}
          <button
            onClick={onToggle}
            className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
          >
            {collapsed ? (
              <Bars3Icon className="w-5 h-5 text-gray-600" />
            ) : (
              <XMarkIcon className="w-5 h-5 text-gray-600" />
            )}
          </button>
        </div>

        {/* Quick Add Button */}
        <div className="p-4">
          <button className={`w-full bg-pink-500 hover:bg-pink-600 text-white rounded-lg transition-colors flex items-center justify-center ${collapsed ? 'p-3' : 'p-3 space-x-2'}`}>
            <PlusIcon className="w-5 h-5" />
            {!collapsed && <span className="font-medium">Quick Add</span>}
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 pb-4">
          <ul className="space-y-2">
            {navigation.map((item) => {
              const isActive = currentView === item.id;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => onViewChange(item.id)}
                    className={`w-full flex items-center rounded-lg transition-colors ${
                      collapsed ? 'p-3 justify-center' : 'p-3 space-x-3'
                    } ${
                      isActive
                        ? 'bg-pink-50 text-pink-700 border border-pink-200'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <item.icon className="w-5 h-5 flex-shrink-0" />
                    {!collapsed && <span className="font-medium">{item.name}</span>}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>
      </div>
    </div>
  );
}
