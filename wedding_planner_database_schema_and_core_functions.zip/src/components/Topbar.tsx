import { 
  MagnifyingGlassIcon, 
  BellIcon, 
  UserCircleIcon 
} from "@heroicons/react/24/outline";
import { SignOutButton } from "../SignOutButton";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function Topbar() {
  const user = useQuery(api.auth.loggedInUser);

  return (
    <header className="bg-white border-b border-gray-200 px-8 py-4">
      <div className="flex items-center justify-between">
        {/* Search */}
        <div className="flex-1 max-w-lg">
          <div className="relative">
            <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search clients, projects... (⌘K)"
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-pink-500 outline-none"
            />
          </div>
        </div>

        {/* Right side */}
        <div className="flex items-center space-x-4">
          {/* Notifications */}
          <button className="p-2 text-gray-400 hover:text-gray-600 relative">
            <BellIcon className="w-6 h-6" />
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
          </button>

          {/* Profile */}
          <div className="flex items-center space-x-3">
            <div className="text-right">
              <p className="text-sm font-medium text-gray-900">
                {user?.name || user?.email || "User"}
              </p>
              <p className="text-xs text-gray-500">Wedding Planner</p>
            </div>
            <UserCircleIcon className="w-8 h-8 text-gray-400" />
            <SignOutButton />
          </div>
        </div>
      </div>
    </header>
  );
}
