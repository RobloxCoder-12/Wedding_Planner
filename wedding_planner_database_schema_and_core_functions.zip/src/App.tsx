import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { Dashboard } from "./components/Dashboard";
import { Sidebar } from "./components/Sidebar";
import { Topbar } from "./components/Topbar";
import { ClientsPage } from "./components/ClientsPage";
import { ProjectsPage } from "./components/ProjectsPage";
import { CalendarPage } from "./components/CalendarPage";
import { VendorsPage } from "./components/VendorsPage";
import { LeadsPage } from "./components/LeadsPage";
import { ReportsPage } from "./components/ReportsPage";
import { useState } from "react";

export default function App() {
  const [currentView, setCurrentView] = useState("dashboard");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  return (
    <div className="min-h-screen flex bg-gray-50">
      <Authenticated>
        <Sidebar 
          collapsed={sidebarCollapsed}
          onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
          currentView={currentView}
          onViewChange={setCurrentView}
        />
        <div className="flex-1 flex flex-col">
          <Topbar />
          <main className="flex-1 p-8">
            <div className="max-w-[1200px] mx-auto">
              {currentView === "dashboard" && <Dashboard />}
              {currentView === "clients" && <ClientsPage />}
              {currentView === "projects" && <ProjectsPage />}
              {currentView === "calendar" && <CalendarPage />}
              {currentView === "vendors" && <VendorsPage />}
              {currentView === "leads" && <LeadsPage />}
              {currentView === "reports" && <ReportsPage />}
            </div>
          </main>
        </div>
      </Authenticated>

      <Unauthenticated>
        <div className="flex-1 flex items-center justify-center p-8">
          <div className="w-full max-w-md mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">EverAfter Planner</h1>
              <p className="text-xl text-gray-600">Your wedding planning dashboard</p>
            </div>
            <SignInForm />
          </div>
        </div>
      </Unauthenticated>

      <Toaster />
    </div>
  );
}
