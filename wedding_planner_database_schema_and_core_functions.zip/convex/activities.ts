import { query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const activities = await ctx.db.query("activities")
      .withIndex("by_created_by", (q) => q.eq("createdBy", userId))
      .order("desc")
      .take(args.limit || 10);

    return activities;
  },
});
