import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {
    status: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    if (args.status) {
      return await ctx.db.query("leads")
        .withIndex("by_status", (q) => q.eq("status", args.status!))
        .collect();
    } else {
      return await ctx.db.query("leads")
        .withIndex("by_created_by", (q) => q.eq("createdBy", userId))
        .collect();
    }
  },
});

export const create = mutation({
  args: {
    name: v.string(),
    email: v.string(),
    phone: v.optional(v.string()),
    weddingDate: v.optional(v.string()),
    venue: v.optional(v.string()),
    estimatedBudget: v.optional(v.number()),
    source: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const leadId = await ctx.db.insert("leads", {
      ...args,
      status: "new",
      createdBy: userId,
    });

    // Log activity
    await ctx.db.insert("activities", {
      type: "lead_created",
      description: `New lead: ${args.name}`,
      entityId: leadId,
      entityType: "lead",
      createdBy: userId,
    });

    return leadId;
  },
});

export const updateStatus = mutation({
  args: {
    id: v.id("leads"),
    status: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    await ctx.db.patch(args.id, { 
      status: args.status,
      lastContactDate: args.status !== "new" ? new Date().toISOString() : undefined,
    });

    return args.id;
  },
});

export const convertToClient = mutation({
  args: {
    id: v.id("leads"),
    budget: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const lead = await ctx.db.get(args.id);
    if (!lead) throw new Error("Lead not found");

    // Create client from lead
    const clientId = await ctx.db.insert("clients", {
      name: lead.name,
      email: lead.email,
      phone: lead.phone,
      weddingDate: lead.weddingDate,
      venue: lead.venue,
      budget: args.budget,
      status: "active",
      notes: lead.notes,
      createdBy: userId,
    });

    // Update lead status
    await ctx.db.patch(args.id, { status: "booked" });

    // Log activity
    await ctx.db.insert("activities", {
      type: "lead_converted",
      description: `Converted lead ${lead.name} to client`,
      entityId: clientId,
      entityType: "client",
      createdBy: userId,
    });

    return clientId;
  },
});

export const getStats = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const leads = await ctx.db.query("leads")
      .withIndex("by_created_by", (q) => q.eq("createdBy", userId))
      .collect();

    const totalLeads = leads.length;
    const newLeads = leads.filter(l => l.status === "new").length;
    const convertedLeads = leads.filter(l => l.status === "booked").length;
    const conversionRate = totalLeads > 0 ? (convertedLeads / totalLeads) * 100 : 0;

    return {
      total: totalLeads,
      new: newLeads,
      converted: convertedLeads,
      conversionRate: Math.round(conversionRate),
    };
  },
});
