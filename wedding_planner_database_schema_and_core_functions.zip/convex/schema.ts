import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  clients: defineTable({
    name: v.string(),
    email: v.string(),
    phone: v.optional(v.string()),
    weddingDate: v.optional(v.string()),
    venue: v.optional(v.string()),
    budget: v.optional(v.number()),
    status: v.string(), // "lead", "active", "completed"
    notes: v.optional(v.string()),
    createdBy: v.id("users"),
  })
    .index("by_status", ["status"])
    .index("by_created_by", ["createdBy"]),

  projects: defineTable({
    clientId: v.id("clients"),
    title: v.string(),
    weddingDate: v.string(),
    venue: v.string(),
    budget: v.number(),
    spent: v.number(),
    status: v.string(), // "planning", "in-progress", "completed"
    description: v.optional(v.string()),
    heroImage: v.optional(v.id("_storage")),
    createdBy: v.id("users"),
  })
    .index("by_client", ["clientId"])
    .index("by_status", ["status"])
    .index("by_created_by", ["createdBy"]),

  tasks: defineTable({
    projectId: v.id("projects"),
    title: v.string(),
    description: v.optional(v.string()),
    dueDate: v.optional(v.string()),
    completed: v.boolean(),
    priority: v.string(), // "low", "medium", "high"
    assignedTo: v.optional(v.id("users")),
    category: v.string(), // "venue", "catering", "photography", "flowers", "music", "other"
    createdBy: v.id("users"),
  })
    .index("by_project", ["projectId"])
    .index("by_assigned_to", ["assignedTo"])
    .index("by_due_date", ["dueDate"]),

  timelineItems: defineTable({
    projectId: v.id("projects"),
    title: v.string(),
    date: v.string(),
    time: v.optional(v.string()),
    description: v.optional(v.string()),
    type: v.string(), // "milestone", "vendor", "task", "event"
    vendorId: v.optional(v.id("vendors")),
    taskId: v.optional(v.id("tasks")),
    order: v.number(),
    createdBy: v.id("users"),
  })
    .index("by_project", ["projectId"])
    .index("by_date", ["date"]),

  vendors: defineTable({
    name: v.string(),
    category: v.string(), // "venue", "catering", "photography", "flowers", "music", "other"
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    website: v.optional(v.string()),
    rating: v.optional(v.number()),
    priceRange: v.string(), // "$", "$$", "$$$", "$$$$"
    description: v.optional(v.string()),
    portfolio: v.optional(v.array(v.id("_storage"))),
    createdBy: v.id("users"),
  })
    .index("by_category", ["category"])
    .index("by_rating", ["rating"]),

  leads: defineTable({
    name: v.string(),
    email: v.string(),
    phone: v.optional(v.string()),
    weddingDate: v.optional(v.string()),
    venue: v.optional(v.string()),
    estimatedBudget: v.optional(v.number()),
    status: v.string(), // "new", "contacted", "proposal", "booked", "lost"
    source: v.optional(v.string()), // "website", "referral", "social", "other"
    notes: v.optional(v.string()),
    lastContactDate: v.optional(v.string()),
    createdBy: v.id("users"),
  })
    .index("by_status", ["status"])
    .index("by_created_by", ["createdBy"]),

  expenses: defineTable({
    projectId: v.id("projects"),
    vendorId: v.optional(v.id("vendors")),
    category: v.string(),
    description: v.string(),
    amount: v.number(),
    date: v.string(),
    status: v.string(), // "pending", "paid", "overdue"
    createdBy: v.id("users"),
  })
    .index("by_project", ["projectId"])
    .index("by_vendor", ["vendorId"])
    .index("by_status", ["status"]),

  activities: defineTable({
    type: v.string(), // "client_created", "project_created", "task_completed", etc.
    description: v.string(),
    entityId: v.optional(v.string()), // ID of related entity
    entityType: v.optional(v.string()), // "client", "project", "task", etc.
    createdBy: v.id("users"),
  })
    .index("by_created_by", ["createdBy"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
