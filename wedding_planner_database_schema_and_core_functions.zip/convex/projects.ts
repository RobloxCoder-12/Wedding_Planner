import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {
    clientId: v.optional(v.id("clients")),
    status: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    let projects;

    if (args.clientId) {
      projects = await ctx.db.query("projects")
        .withIndex("by_client", (q) => q.eq("clientId", args.clientId!))
        .collect();
    } else if (args.status) {
      projects = await ctx.db.query("projects")
        .withIndex("by_status", (q) => q.eq("status", args.status!))
        .collect();
    } else {
      projects = await ctx.db.query("projects")
        .withIndex("by_created_by", (q) => q.eq("createdBy", userId))
        .collect();
    }

    // Get client info for each project
    const projectsWithClients = await Promise.all(
      projects.map(async (project) => {
        const client = await ctx.db.get(project.clientId);
        return {
          ...project,
          client,
        };
      })
    );

    return projectsWithClients;
  },
});

export const get = query({
  args: { id: v.id("projects") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const project = await ctx.db.get(args.id);
    if (!project) return null;

    const client = await ctx.db.get(project.clientId);
    
    // Get tasks for this project
    const tasks = await ctx.db.query("tasks")
      .withIndex("by_project", (q) => q.eq("projectId", args.id))
      .collect();

    // Get timeline items for this project
    const timelineItems = await ctx.db.query("timelineItems")
      .withIndex("by_project", (q) => q.eq("projectId", args.id))
      .order("asc")
      .collect();

    // Get expenses for this project
    const expenses = await ctx.db.query("expenses")
      .withIndex("by_project", (q) => q.eq("projectId", args.id))
      .collect();

    return {
      ...project,
      client,
      tasks,
      timelineItems,
      expenses,
    };
  },
});

export const create = mutation({
  args: {
    clientId: v.id("clients"),
    title: v.string(),
    weddingDate: v.string(),
    venue: v.string(),
    budget: v.number(),
    description: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const projectId = await ctx.db.insert("projects", {
      ...args,
      spent: 0,
      status: "planning",
      createdBy: userId,
    });

    // Update client status to active
    await ctx.db.patch(args.clientId, { status: "active" });

    // Log activity
    await ctx.db.insert("activities", {
      type: "project_created",
      description: `Created new project: ${args.title}`,
      entityId: projectId,
      entityType: "project",
      createdBy: userId,
    });

    return projectId;
  },
});

export const update = mutation({
  args: {
    id: v.id("projects"),
    title: v.optional(v.string()),
    weddingDate: v.optional(v.string()),
    venue: v.optional(v.string()),
    budget: v.optional(v.number()),
    spent: v.optional(v.number()),
    status: v.optional(v.string()),
    description: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const { id, ...updates } = args;
    await ctx.db.patch(id, updates);

    return id;
  },
});

export const getStats = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const projects = await ctx.db.query("projects")
      .withIndex("by_created_by", (q) => q.eq("createdBy", userId))
      .collect();

    const totalProjects = projects.length;
    const activeProjects = projects.filter(p => p.status === "planning" || p.status === "in-progress").length;
    const completedProjects = projects.filter(p => p.status === "completed").length;
    const totalRevenue = projects.reduce((sum, p) => sum + p.budget, 0);

    return {
      total: totalProjects,
      active: activeProjects,
      completed: completedProjects,
      revenue: totalRevenue,
    };
  },
});
