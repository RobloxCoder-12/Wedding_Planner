import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {
    projectId: v.optional(v.id("projects")),
    assignedTo: v.optional(v.id("users")),
    completed: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    let tasks;

    if (args.projectId) {
      tasks = await ctx.db.query("tasks")
        .withIndex("by_project", (q) => q.eq("projectId", args.projectId!))
        .collect();
    } else if (args.assignedTo) {
      tasks = await ctx.db.query("tasks")
        .withIndex("by_assigned_to", (q) => q.eq("assignedTo", args.assignedTo!))
        .collect();
    } else {
      // Get all tasks created by this user
      tasks = await ctx.db.query("tasks").collect();
      tasks = tasks.filter(task => task.createdBy === userId);
    }

    if (args.completed !== undefined) {
      return tasks.filter(task => task.completed === args.completed);
    }

    return tasks;
  },
});

export const create = mutation({
  args: {
    projectId: v.id("projects"),
    title: v.string(),
    description: v.optional(v.string()),
    dueDate: v.optional(v.string()),
    priority: v.string(),
    assignedTo: v.optional(v.id("users")),
    category: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const taskId = await ctx.db.insert("tasks", {
      ...args,
      completed: false,
      createdBy: userId,
    });

    // Log activity
    await ctx.db.insert("activities", {
      type: "task_created",
      description: `Created new task: ${args.title}`,
      entityId: taskId,
      entityType: "task",
      createdBy: userId,
    });

    return taskId;
  },
});

export const toggle = mutation({
  args: {
    id: v.id("tasks"),
    completed: v.boolean(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    await ctx.db.patch(args.id, { completed: args.completed });

    if (args.completed) {
      const task = await ctx.db.get(args.id);
      if (task) {
        await ctx.db.insert("activities", {
          type: "task_completed",
          description: `Completed task: ${task.title}`,
          entityId: args.id,
          entityType: "task",
          createdBy: userId,
        });
      }
    }

    return args.id;
  },
});

export const update = mutation({
  args: {
    id: v.id("tasks"),
    title: v.optional(v.string()),
    description: v.optional(v.string()),
    dueDate: v.optional(v.string()),
    priority: v.optional(v.string()),
    assignedTo: v.optional(v.id("users")),
    category: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const { id, ...updates } = args;
    await ctx.db.patch(id, updates);

    return id;
  },
});

export const remove = mutation({
  args: { id: v.id("tasks") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    await ctx.db.delete(args.id);
    return args.id;
  },
});
