import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {
    status: v.optional(v.string()),
    search: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    let clients;

    if (args.status) {
      clients = await ctx.db.query("clients")
        .withIndex("by_status", (q) => q.eq("status", args.status!))
        .collect();
    } else {
      clients = await ctx.db.query("clients")
        .withIndex("by_created_by", (q) => q.eq("createdBy", userId))
        .collect();
    }

    if (args.search) {
      const searchTerm = args.search.toLowerCase();
      return clients.filter(client => 
        client.name.toLowerCase().includes(searchTerm) ||
        client.email.toLowerCase().includes(searchTerm)
      );
    }

    return clients;
  },
});

export const get = query({
  args: { id: v.id("clients") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.get(args.id);
  },
});

export const create = mutation({
  args: {
    name: v.string(),
    email: v.string(),
    phone: v.optional(v.string()),
    weddingDate: v.optional(v.string()),
    venue: v.optional(v.string()),
    budget: v.optional(v.number()),
    status: v.string(),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const clientId = await ctx.db.insert("clients", {
      ...args,
      createdBy: userId,
    });

    // Log activity
    await ctx.db.insert("activities", {
      type: "client_created",
      description: `Created new client: ${args.name}`,
      entityId: clientId,
      entityType: "client",
      createdBy: userId,
    });

    return clientId;
  },
});

export const update = mutation({
  args: {
    id: v.id("clients"),
    name: v.optional(v.string()),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    weddingDate: v.optional(v.string()),
    venue: v.optional(v.string()),
    budget: v.optional(v.number()),
    status: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const { id, ...updates } = args;
    await ctx.db.patch(id, updates);

    return id;
  },
});

export const remove = mutation({
  args: { id: v.id("clients") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    await ctx.db.delete(args.id);
    return args.id;
  },
});

export const getStats = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const clients = await ctx.db.query("clients")
      .withIndex("by_created_by", (q) => q.eq("createdBy", userId))
      .collect();

    const totalClients = clients.length;
    const activeClients = clients.filter(c => c.status === "active").length;
    const completedClients = clients.filter(c => c.status === "completed").length;

    return {
      total: totalClients,
      active: activeClients,
      completed: completedClients,
    };
  },
});
